import requests
#import xbmcvfs
#import xmbc
#import xbmcaddon
import fileinput
import os
import sys
#import urllib.request
import urllib
import time

#r = requests.get('http://stenographic-gun.000webhostapp.com/realphp.php')
#data = r.json()

#fp = urllib.request.urlopen("http://stenographic-gun.000webhostapp.com/realphp.php")
fp = urllib.urlopen("http://stenographic-gun.000webhostapp.com/realphp.php")
mybytes = fp.read()

mystr = mybytes.decode("utf8")
fp.close()

#with fileinput.FileInput("./resources/data/m3utemplate.m3u"), inplace=True, backup='.bak') as file:
#    for line in file:
#        print(line.replace("REPLACEME", r), end='')
replacements = {'REPLACEME':mystr}

while True:
	with open('./resources/data/m3utemplate.m3u') as infile, open('./resources/data/finalm3u.m3u', 'w') as outfile:
		for line in infile:
			for src, target in replacements.iteritems():
				line = line.replace(src, target)
			outfile.write(line)
	time.sleep(10800)